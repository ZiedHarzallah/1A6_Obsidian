#ifndef JEU_H_INCLUDED
#define JEU_H_INCLUDED
#include <SDL/SDL.h>
/**
* @struct background
* @brief struct for background
*/
typedef struct 
{
	SDL_Surface *BG; /*!< Surface. */
	SDL_Rect posBG;	/*!< Rectangle. */
}background;


void scrolling(SDL_Surface *ecran,background bg,int continuer);


#endif // JEU_H_INCLUDED
