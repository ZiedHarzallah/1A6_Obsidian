/**
* @file background.c
*/


#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include "background.h"



void scrolling(SDL_Surface *ecran,background bg,int continuer)
     {
    
    int speed=50;

    bg.posBG.x = 0;
    bg.posBG.y = 0;
    bg.posBG.h =361;
    bg.posBG.w =4096;
    bg.BG = IMG_Load("map.png");
   
   
    SDL_BlitSurface(bg.BG,&bg.posBG, ecran, NULL);
              
    SDL_Flip(ecran);
    
 
    SDL_Event event;

 
    while (continuer)
    {
        SDL_WaitEvent(&event);
        switch(event.type)
        {
            case SDL_QUIT:
                continuer = 0;
                break;
            case SDL_KEYDOWN:

        switch(event.key.keysym.sym)

        {

            case SDLK_RIGHT: // Flèche droite
            	
                if  ( bg.posBG.x<=2500)
            bg.posBG.x += speed;
		if (bg.posBG.x==bg.posBG.w)
	    bg.posBG.x=0;

     
            
       
                SDL_BlitSurface(bg.BG,&bg.posBG, ecran, NULL);
            
                
    SDL_Flip(ecran);

                break;

            case SDLK_LEFT: // Flèche gauche
            	if ( bg.posBG.x>=0)
        
            bg.posBG.x -= speed;
     
         
                SDL_BlitSurface(bg.BG,&bg.posBG, ecran, NULL);
				
                
    SDL_Flip(ecran);

             
       



        }

        break;    
        }

       
        
    SDL_Flip(ecran);
    }
/**
* @brief To scroll the background .
* @param ecran to the screen of the program
* @param bg to the background
* @param continuer to the  state of the program
* @return Nothing
*/
}
