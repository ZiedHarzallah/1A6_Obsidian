/**
* @file main.c
* @brief Testing Program
* @author Trabelsi Karim
* @version 1.0
* @date June 11, 2015
*
* Testing program for background scrolling
*
*/


#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include "background.h"
int main()
{
SDL_Surface *ecran=NULL;
int continuer=1;
SDL_Rect positionFond;
SDL_Init(SDL_INIT_VIDEO);
background bg;
    ecran = SDL_SetVideoMode(1000, 361, 32, SDL_HWSURFACE|SDL_DOUBLEBUF);
    SDL_WM_SetCaption("Scrolling background", NULL);  
	
	scrolling(ecran,bg,continuer);


SDL_FreeSurface(bg.BG);
 SDL_Quit();

    return EXIT_SUCCESS;
}
