var searchData=
[
  ['bg',['BG',['../structbackground.html#a2ec25e9f05c19b822e472f74f6bbc872',1,'background']]]
];
