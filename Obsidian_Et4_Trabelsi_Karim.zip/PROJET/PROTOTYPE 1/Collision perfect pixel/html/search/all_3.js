var searchData=
[
  ['getpixel',['GetPixel',['../background_8c.html#ac0b09099bd2e6c0b932b64a441461a19',1,'GetPixel(SDL_Surface *background_mask, int x, int y):&#160;background.c'],['../background_8h.html#ac0b09099bd2e6c0b932b64a441461a19',1,'GetPixel(SDL_Surface *background_mask, int x, int y):&#160;background.c']]]
];
