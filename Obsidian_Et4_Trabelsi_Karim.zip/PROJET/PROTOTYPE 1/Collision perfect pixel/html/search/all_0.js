var searchData=
[
  ['animation',['animation',['../background_8c.html#af093cbf86e6c9b7d1447fccd90fde212',1,'animation(SDL_Surface *screen, SDL_Rect perso):&#160;background.c'],['../background_8h.html#af093cbf86e6c9b7d1447fccd90fde212',1,'animation(SDL_Surface *screen, SDL_Rect perso):&#160;background.c']]]
];
