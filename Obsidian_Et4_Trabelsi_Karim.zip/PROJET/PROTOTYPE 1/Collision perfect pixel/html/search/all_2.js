var searchData=
[
  ['detectcollpp',['detectCollPP',['../background_8c.html#a0efbc72b58072d90c7bbf85b93bca54b',1,'detectCollPP(SDL_Surface *BackgroundMasque, SDL_Rect Personnage):&#160;background.c'],['../background_8h.html#a0efbc72b58072d90c7bbf85b93bca54b',1,'detectCollPP(SDL_Surface *BackgroundMasque, SDL_Rect Personnage):&#160;background.c']]]
];
