var searchData=
[
  ['background',['background',['../structbackground.html',1,'background'],['../structBackground.html',1,'Background']]],
  ['background_2ec',['background.c',['../background_8c.html',1,'']]],
  ['background_2eh',['background.h',['../background_8h.html',1,'']]],
  ['bg',['BG',['../structbackground.html#a2ec25e9f05c19b822e472f74f6bbc872',1,'background']]]
];
