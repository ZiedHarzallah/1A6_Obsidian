/**
* @file main.c
* @brief Testing Program.
* @author Trabelsi Karim	
* @version 1.0
* @date June 18, 2020
*
* Testing program for collision pp
*
*/
#include <stdio.h>
#include  <stdlib.h>
#include  <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <string.h>
#include "background.h"

int main()
{
int continuer;
SDL_Surface *screen ; 
background bg;
SDL_Rect perso;
SDL_Event event ; 
int done=0 , x,xx=0 ; 
perso.x=360;
perso.y=200;


 if  ( SDL_Init ( SDL_INIT_VIDEO )  == -1 )  { 
         printf ( "Can not init SDL \n " ); 
 
     } 

     screen  =  SDL_SetVideoMode ( 1000 , 361 ,  32 ,  SDL_HWSURFACE  |  SDL_DOUBLEBUF ); 
     if  ( screen  ==  NULL )  { 
         printf ( "Can not set video mode: \n "); 
         
     }
animation(screen,perso);
return 0 ; 
}
