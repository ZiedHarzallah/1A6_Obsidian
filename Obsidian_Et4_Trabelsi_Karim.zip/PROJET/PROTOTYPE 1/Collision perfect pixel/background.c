/**
* @file background.c
*/
#include <stdio.h>
#include  <stdlib.h>
#include  <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <string.h>
#include "background.h"

/**
* @brief To get pixel from the mask .
* @param background_mask to the masked image
* @param x to the x coordinate
* @param y to the y coordinate
* @return color
*/
SDL_Color GetPixel(SDL_Surface *background_mask,int x,int y)
{
SDL_Color color;
Uint32 col=0;
char* pPosition=(char* ) background_mask->pixels;
pPosition+= (background_mask->pitch * y);
pPosition+= (background_mask->format->BytesPerPixel *x);
memcpy(&col ,pPosition ,background_mask->format->BytesPerPixel);
SDL_GetRGB(col,background_mask->format, &color.r, &color.g, &color.b);
return (color);
}


/**
* @brief To detect the collision.
* @param background_mask to the masked image
* @param personnage to the player
* @return collision
*/
int detectCollPP (SDL_Surface * BackgroundMasque, SDL_Rect Personnage){


  SDL_Color colobs;

  SDL_Color colgotten;

  SDL_Rect Pos[8];

int collision = 0, i = 0;
colobs.r=0;
colobs.g=0;
colobs.b=0;

  Pos[0].x = Personnage.x;

  Pos[0].y = Personnage.y;

  Pos[1].x = Personnage.x + (Personnage.w /2);

  Pos[1].y = Personnage.y;

  Pos[2].x = Personnage.x + Personnage.w;

  Pos[2].y = Personnage.y;

  Pos[3].x = Personnage.x;

  Pos[3].y =  Personnage.y + (Personnage.h/2);

  Pos[4].x = Personnage.x;

  Pos[4].y = Personnage.y + Personnage.h;

  Pos[5].x = Personnage.x + (Personnage.w /2);

  Pos[5].y =  Personnage.y + Personnage.h;

  Pos[6].x = Personnage.x + Personnage.w;

  Pos[6].y = Personnage.y + Personnage.h;

  Pos[7].x = Personnage.x + Personnage.w;

  Pos[7].y = Personnage.y + (Personnage.h/2);

while ((i<=7) && (collision == 0)) {
colgotten = GetPixel (BackgroundMasque, Pos[i].x, Pos[i].y);


    if ((colobs.r == colgotten.r) &&  (colobs.b == colgotten.b) &&

  (colobs.g == colgotten.g)){

       collision = 1;

    }else{

      i++;

    }

}

return collision;
}
/**
* @brief animate the player .
* @param screen to the program screen
* @param perso to the player
* @return Nothing
*/
void animation(SDL_Surface *screen,SDL_Rect perso)
{
SDL_Event event ; 
int done=0,x,xx=0;
SDL_Surface *back1,*back2,*back3 ; 
back1=IMG_Load( "mapmini1.png" );
back2=IMG_Load( "mapmini2.png" );
back3=IMG_Load( "perso.png" );
SDL_BlitSurface ( back2,  NULL ,  screen , NULL );

SDL_BlitSurface ( back1,  NULL ,  screen , NULL );
SDL_BlitSurface ( back3,  NULL ,  screen , &perso );

SDL_Flip ( screen ); 
   
   SDL_EnableKeyRepeat(10,10) ; 
    while  ( done==0 )  { 
         while  (SDL_PollEvent ( &event ))  { 
             switch  ( event.type )  { 
             case  SDL_QUIT : 
                 done  =  1 ; 
                 break ;  
    case SDL_KEYDOWN:

        switch(event.key.keysym.sym)

        {
      case SDLK_ESCAPE : 
done=1 ; 

case SDLK_LEFT : 

perso.x-=10 ; 
xx=detectCollPP(back2,perso) ;
if(xx==1)
{
perso.x+=10;
}
SDL_BlitSurface ( back2,  NULL ,  screen , NULL );

SDL_BlitSurface ( back1,  NULL ,  screen , NULL );
SDL_BlitSurface ( back3,  NULL ,  screen , &perso );

SDL_Flip ( screen ); 

break ; 

case SDLK_RIGHT : 
perso.x+=10 ; 
xx=detectCollPP (back2,perso) ;
if(xx==1)
{
perso.x-=10 ; 
}
SDL_BlitSurface ( back2,  NULL ,  screen , NULL );

SDL_BlitSurface ( back1,  NULL ,  screen , NULL );
SDL_BlitSurface ( back3,  NULL ,  screen , &perso );

SDL_Flip ( screen ); 

break ; 
case SDLK_UP : 

perso.y-=10 ; 
xx=detectCollPP (back2,perso) ;
if(xx==1)
{
perso.y+=10;
}
x=detectCollPP (back2,perso) ;
SDL_BlitSurface ( back2,  NULL ,  screen , NULL );

SDL_BlitSurface ( back1,  NULL ,  screen , NULL );
SDL_BlitSurface ( back3,  NULL ,  screen , &perso );

SDL_Flip ( screen ); 

break ; 
case SDLK_DOWN : 

perso.y+=10 ;
xx=detectCollPP (back2,perso) ;
if(xx==1)
{
perso.y-=10;
}

SDL_BlitSurface ( back2,  NULL ,  screen , NULL );

SDL_BlitSurface ( back1,  NULL ,  screen , NULL );
SDL_BlitSurface ( back3,  NULL ,  screen , &perso );

SDL_Flip ( screen ); 

break ; 


                 
			 }


if(x==1) 
{
SDL_FillRect ( screen ,  NULL ,  SDL_MapRGB ( screen -> format,  0,  0 , 0));
SDL_Flip(screen) ; 
}
break ; 

		 }
	 }


}
}


