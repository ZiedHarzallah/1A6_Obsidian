var searchData=
[
  ['loadimage',['Loadimage',['../scrolling_8c.html#a4621fd710987876472baa41bfeefc56c',1,'Loadimage(const char *fich):&#160;scrolling.c'],['../scrolling_8h.html#a4621fd710987876472baa41bfeefc56c',1,'Loadimage(const char *fich):&#160;scrolling.c']]]
];
