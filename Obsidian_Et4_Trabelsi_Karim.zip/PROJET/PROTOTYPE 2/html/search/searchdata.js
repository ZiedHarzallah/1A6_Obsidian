var indexSectionsWithContent =
{
  0: "acdhilmnrsuv",
  1: "aimsv",
  2: "dims",
  3: "acilmnrsu",
  4: "hiv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables"
};

