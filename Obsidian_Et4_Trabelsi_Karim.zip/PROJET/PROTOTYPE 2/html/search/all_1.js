var searchData=
[
  ['clampmap',['clampMap',['../scrolling_8c.html#a97d4ce71929ec564f9b5fe681db19f29',1,'scrolling.c']]]
];
