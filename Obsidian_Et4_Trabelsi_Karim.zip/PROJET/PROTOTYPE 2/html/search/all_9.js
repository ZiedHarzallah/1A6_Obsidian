var searchData=
[
  ['scrollcenter',['scrollcenter',['../scrolling_8c.html#a885cdc1441e4e28d7df2b7c70128224b',1,'scrolling.c']]],
  ['scrolling_2ec',['scrolling.c',['../scrolling_8c.html',1,'']]],
  ['scrolling_2eh',['scrolling.h',['../scrolling_8h.html',1,'']]],
  ['sprite',['Sprite',['../structSprite.html',1,'']]],
  ['spritesheet',['Spritesheet',['../structSpritesheet.html',1,'']]]
];
